<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Joined LUXE</title>
</head>
<style>
    * {
        font-family: 'Montserrat';
        font-weight: 400;
    }

    @page {
        padding: 0px;
        margin: 0px;
        size: 4000px 4000px;
    }

    body {
        padding: 0px;
        margin: 0px;
    }

    .page {
        background-image: url({{ $img_1_input }});
        position: absolute;
        background-position: right top;
        background-repeat: no-repeat;
        background-size: 2700px 3750px;
    }

    .absolute {
        position: absolute;
    }

    .gold {
        color: #C5A467;
    }

    .white {
        color: white;
    }

    .bold {
        font-weight: 700;
    }

    ul li {
        display: inline;
        font-size: 90px;
    }

    h1,
    h2,
    h3,
    p {
        margin: 0;
    }

    div.circle {
        top: 67.1%;
    }

    img.circle {
        border-radius: 350px;
        width: 700px;
        height: 700px;
        object-fit: cover;
    }
</style>

<body>
    <div class="page">
        <div>
            <img src="images/themes/joined-luxe/main.png" alt="" style="width: 4000px;height:4000px;">
        </div>
        <div class="absolute" style="top:62.7%;left:290px;">
            <h1 class="bold" style="font-size: 230px;line-height:140px;">{{ $page_1_text_1 }}</h1>
            <h1 class="bold" style="font-size: 330px;line-height:250px;">{{ $page_1_text_2 }}</h1>
        </div>
        <div class="absolute" style="top:75%;left: 200px;">
            <ul>
                <li class="page-1-text-3 white">{{ $page_1_text_3 }}</li>
            </ul>
        </div>
        <div class="absolute" style="bottom:6.9%;left:520px;">
            <h1 class="white" style="font-size: 50px;line-height:40px;letter-spacing: 12px;">{{ $page_1_text_4 }}</h1>
            <h1 class="gold bold" style="font-size: 100px;line-height:80px;">{{ $page_1_text_5 }}</h1>
        </div>
    </div>
</body>

</html>