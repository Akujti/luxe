<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Joined LUXE</title>
</head>
<style>
    * {
        font-family: 'Montserrat';
        font-weight: 400;
    }

    @page {
        padding: 0px;
        margin: 0px;
        size: 4000px 7100px;
    }

    body {
        padding: 0px;
        margin: 0px;
    }

    .page {
        background-image: url({{ $img_1_input }});
        position: absolute;
        background-position: right top;
        background-repeat: no-repeat;
        background-size: 3685px 5118px;
    }

    .absolute {
        position: absolute;
    }

    .gold {
        color: #C5A467;
    }

    .white {
        color: white;
    }

    .bold {
        font-weight: 700;
    }

    ul li {
        display: inline;
        font-size: 100px;
    }

    h1,
    h2,
    h3,
    p {
        margin: 0;
    }

    div.circle {
        top: 67.1%;
    }

    img.circle {
        border-radius: 350px;
        width: 700px;
        height: 700px;
        object-fit: cover;
    }
</style>

<body>
    <div class="page">
        <div>
            <img src="images/themes/joined-luxe-story/main.png" alt="" style="width: 4000px;height:7100px;">
        </div>
        <div class="absolute" style="top:72%;left:420px;">
            <h1 class="bold" style="font-size: 300px;line-height:140px;margin-bottom:30px;">{{ $page_1_text_1 }}</h1>
            <h1 class="bold" style="font-size: 400px;line-height:320px;">{{ $page_1_text_2 }}</h1>
        </div>
        <div class="absolute" style="top:81.5%;left: 200px;">
            <ul>
                <li class="page-1-text-3 white">{{ $page_1_text_3 }}</li>
            </ul>
        </div>
        <div class="absolute" style="bottom:4.1%;left:600px;">
            <h1 class="white" style="font-size: 100px;line-height:100px;letter-spacing: 6px;">{{ $page_1_text_4 }}</h1>
            <h1 class="gold bold" style="font-size: 150px;line-height:105px;">{{ $page_1_text_5 }}</h1>
        </div>
    </div>
</body>

</html>